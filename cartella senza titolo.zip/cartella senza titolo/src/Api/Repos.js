import * as data from './Mock/Esempio.json';

const listRepos = () => {
    let repos = data;
    return repos;
}

export default listRepos;