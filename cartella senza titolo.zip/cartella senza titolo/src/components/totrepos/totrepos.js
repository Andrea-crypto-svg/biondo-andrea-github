import './totrepos.css';

const Totrepos = () => {
    return (
        <div className='totrepos'>
            <p>Repository : x</p>
        </div>
    )
}

export default Totrepos;