import './logo.css';

const Logo = () => {
    return (
        <div className='logo'>
            <p>Logo</p>
        </div>
    )
}

export default Logo;