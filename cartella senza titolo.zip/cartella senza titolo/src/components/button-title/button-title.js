import './button-title.css';

const ButtonTitle = () => {
    return (
        <div className='button-title'>
            <p>Visualizza repos - Aggiorna repos - Nuovo utente</p>
        </div>
    )
}

export default ButtonTitle;