import './nav.css';

const Nav = () => {
    return (
        <div className='nav'>
            <div className='navEl'>
                <p></p>
            </div>
            <div className='navEl'>
                <p></p>
            </div>
            <div className='navEl'>
                <p></p>
            </div>
        </div>
    )
}

export default Nav;